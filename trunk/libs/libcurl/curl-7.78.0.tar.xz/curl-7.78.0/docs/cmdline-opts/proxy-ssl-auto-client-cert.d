Long: proxy-ssl-auto-client-cert
Help: Use auto client certificate for proxy (Schannel)
Added: 7.77.0
Category: proxy tls
---
Same as --ssl-auto-client-cert but used in HTTPS proxy context.
